package zombi;

public interface Repairable {

}
